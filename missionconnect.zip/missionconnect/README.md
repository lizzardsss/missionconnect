# MissionConnect (unofficial concept)

A browser-based messaging app concept that lets a family with several missionaries in different missions
talk to everyone from one place. **All mission data is fictional. This project is not affiliated with, endorsed
by, or approved by The Church of Jesus Christ of Latter-day Saints, and it does not use official branding.**
Real use would require explicit authorization from the Church and from each mission's leadership.

## What exists in milestone 1

| Feature | Status |
|---|---|
| Email + password accounts (Supabase Auth) | Implemented |
| Two users connect through a private, single-use, expiring invitation | Implemented |
| Persistent 1:1 messages with real-time delivery | Implemented |
| Family group chats (create, add person, leave) | Implemented |
| Unread counts, optimistic send with retry | Implemented |
| Roles can't be self-granted; missionary enrollment request → admin approval → audit log | Implemented **in the database** (no UI yet) |
| Mission dashboard, companionships, area assignments, mission-wide settings | Not built |
| Missionary "Teaching" tab, Missionaries-in-my-ward tab | Not built |
| Church-wide mandatory safeguards engine | Not built (see Roadmap) |
| Voice / video calls | Not built |
| Church Account sign-in | Not built (needs official Church authorization) |

## Architecture

```
Browser (React + TypeScript, Vite)
   │  supabase-js (anon key, user JWT)
   ▼
Supabase
 ├─ Auth ............ email/password accounts, JWT
 ├─ Postgres ........ tables + Row Level Security + SECURITY DEFINER functions (RPCs)
 └─ Realtime ........ postgres_changes on messages / conversation_members (filtered by RLS)
```

There is no custom server. **Postgres is the security boundary**: the anon key is public by design, so every
rule that matters lives in row level security and in functions that check `auth.uid()` themselves.

**Data model** (`supabase/migrations/0001_init.sql`)

- `profiles` — one per user, created by a trigger on `auth.users`. The trigger reads only `display_name`
  from sign-up metadata; any `role` the browser sends is ignored.
- `invitations` → `accept_invitation()` → `connections` + a direct `conversations` row. Codes are generated
  by the database (80 bits), single-use, expire after 7 days, revocable. Clients can't choose a code.
- `conversations` / `conversation_members` / `messages`. Only members can read or post; the sender must be
  yourself; messages can't be edited or deleted by clients; `created_at` is server-set.
- Group chats via `create_group_chat()`, `add_group_member()`, `leave_group()`. You can only add people you
  are already connected to, so a group can't be used to reach strangers. Max 50 people.
- `missions` (3 fictional), `mission_memberships`, `audit_log`, `review_enrollment()`. A user can only file a
  *pending missionary* request about themselves. Only a verified admin of that mission can approve, and every
  decision is written to the audit log. **Admin rows can only be created with the SQL editor / service role.**

**Front end** (`app/src`): `lib/` holds pure, tested logic (message merge/dedupe, invite parsing);
`components/` holds screens; `auth/` holds the session context. Realtime handling: load history, subscribe,
and re-fetch on every (re)subscribe so a dropped connection can't leave a gap. Messages are sent with a
client-generated id so the realtime echo and the optimistic copy merge instead of duplicating.

## Requirements

- Node.js **22.18 or newer** (the unit tests run TypeScript directly) and npm
- A free Supabase project (https://supabase.com) — or the Supabase CLI for a local stack
- Optional, for database tests: `psql` and any PostgreSQL 14+ server you may create databases on

## Setup

1. **Create a Supabase project.** Note the Project URL and the anon/publishable key
   (Project Settings → API).
2. **Apply the schema.** Open the SQL editor, paste `supabase/migrations/0001_init.sql`, run it. (CLI users:
   `supabase init`, keep the `supabase/migrations` folder, then `supabase db push`.)
3. **Auth settings** (Authentication → Providers → Email). For quick two-user testing turn **Confirm email
   off**; leave it **on** for anything public. If on, add your site URL under Authentication → URL Configuration.
4. **Configure the app.**
   ```bash
   cd app
   cp .env.example .env.local     # fill in VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY
   npm install
   npm run dev                    # http://localhost:5173
   ```
5. **Confirm Realtime is on for the tables.** The migration adds `messages` and `conversation_members` to the
   `supabase_realtime` publication; check Database → Replication if live updates don't arrive.

## Test it

**Automated**

```bash
cd app
npm test            # unit tests for message merge/validation and invite-code parsing
npm run typecheck   # tsc
npm run build       # typecheck + production build

# database tests (creates and drops a throwaway database; never point at your Supabase DB)
PGHOST=localhost PGPORT=5432 PGUSER=postgres PGPASSWORD=postgres npm run test:db
```

`test:db` runs the real migration against plain Postgres with a tiny stand-in for Supabase's `auth.uid()` and
roles, then exercises sign-up, invitations (reuse, expiry, revoke, self-accept), messaging (spoofing, edits,
outsiders), profile visibility, group chats, leaving/ownership transfer, and privilege escalation attempts.

**Manual two-user test (the milestone goal)** — use two browser profiles (or one normal + one private window):

1. Window A: create account **Alice**. Window B: create account **Bob**.
2. A: “Family & invitations” → type “Bob” → **Create invitation** → **Copy link**.
3. B: open the link (or paste it under “Got an invitation?”) → **Accept**. Both now see each other in Chats.
4. A sends a message → it appears in B **without refreshing**. Reply from B. Reload both: history persists.
5. Create account **Carol** in a third profile; connect Alice ↔ Carol the same way.
6. A: Chats → **New family group** → pick Bob and Carol → create. Send from each; all three see everything live.
7. Negative checks: re-open the same invite link as Carol (should say unavailable); in the browser console try
   `from('messages').update(...)` (should be denied).

## Deploy

The app is a static site; Supabase is the backend.

1. Push the repo to GitHub.
2. Vercel/Netlify/Cloudflare Pages: root directory `app`, build `npm run build`, output `dist`.
3. Set env vars `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` (anon key only — never the `service_role` key).
4. In Supabase → Authentication → URL Configuration set the Site URL and add the deployed URL to Redirect URLs.
5. Keep email confirmation on, enable leaked-password protection and CAPTCHA/rate limits for sign-up, and
   review Auth rate limits before inviting anyone.

### Creating a (fictional) mission admin for testing

There is intentionally no UI path to admin. In the SQL editor (runs as an owner, outside RLS):

```sql
insert into public.mission_memberships (user_id, mission_id, role, status, verified_at)
select u.id, m.id, 'admin', 'verified', now()
from auth.users u, public.missions m
where u.email = 'president@example.test' and m.name like 'Evergreen%';
```

## Known limits and honest caveats

- Messages are protected in transit and by access control, but **not end-to-end encrypted**; the project
  operator can read them. Don't call this private-by-design without adding E2EE and a privacy policy.
- No attachments, editing/deleting, typing indicators, push notifications, or message pagination
  (latest 200 per chat load).
- Real deployment would need: minors/consent policy, content reporting & moderation, abuse rate limits,
  data retention rules, and the Church's approval.

## Roadmap

1. Missionary & admin UIs: enrollment request screen, admin review queue, audit log viewer.
2. Mission settings with a **Church-wide safeguards layer** that mission settings can only tighten, never loosen
   (e.g. allowed contact windows, who may message whom), enforced in RLS/RPCs and audited.
3. Companionships and areas; shared companion conversations; teaching-contacts tab.
4. Ward “Missionaries” directory for members.
5. Group voice/video (WebRTC via a managed provider) once policy permits.
6. Church Account sign-in — only with official authorization.
