-- MissionConnect (unofficial concept) — milestone 1 schema
-- Accounts, verified roles, private invitations, direct + group chats, realtime messages.
-- All mission data here is FICTIONAL. Not affiliated with or approved by any church.
--
-- Security model
--   * Every table has row level security (RLS) enabled; clients get only the grants below.
--   * Privileged state (conversations, connections, memberships status, audit log) is changed
--     only through SECURITY DEFINER functions that check auth.uid() themselves.
--   * Users can never grant themselves a privileged role: they may only file a *pending*
--     missionary enrollment request; an already-verified mission admin approves it.
--     Admin rows can only be created with the service role / SQL editor (see README).

-- ───────────────────────────── profiles ─────────────────────────────
create table public.profiles (
  id           uuid primary key references auth.users (id) on delete cascade,
  display_name text not null check (char_length(display_name) between 1 and 60),
  created_at   timestamptz not null default now()
);

-- Creates the profile on sign-up. Deliberately ignores any client-supplied role/metadata
-- other than display_name.
create function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  n text;
begin
  n := left(btrim(coalesce(new.raw_user_meta_data ->> 'display_name', split_part(coalesce(new.email, ''), '@', 1), '')), 60);
  if n is null or char_length(n) = 0 then
    n := 'Member';
  end if;
  insert into public.profiles (id, display_name) values (new.id, n);
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ───────────────────── fictional missions + verified roles ─────────────────────
create table public.missions (
  id          uuid primary key default gen_random_uuid(),
  name        text not null unique,
  is_fictional boolean not null default true
);

insert into public.missions (name) values
  ('Evergreen Valley Mission (fictional)'),
  ('Harbor Lights Mission (fictional)'),
  ('Desert Rose Mission (fictional)');

create table public.mission_memberships (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references public.profiles (id) on delete cascade,
  mission_id  uuid not null references public.missions (id) on delete cascade,
  role        text not null check (role in ('missionary', 'admin')),
  status      text not null default 'pending' check (status in ('pending', 'verified', 'rejected')),
  verified_by uuid references public.profiles (id),
  verified_at timestamptz,
  created_at  timestamptz not null default now(),
  unique (user_id, mission_id)
);

create function public.is_mission_admin(p_mission uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.mission_memberships
    where user_id = auth.uid() and mission_id = p_mission
      and role = 'admin' and status = 'verified'
  );
$$;

create table public.audit_log (
  id         bigint generated always as identity primary key,
  mission_id uuid not null references public.missions (id) on delete cascade,
  actor_id   uuid not null references public.profiles (id),
  action     text not null,
  target_id  uuid,
  details    jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- Verified admin of the mission approves or rejects a pending missionary enrollment.
create function public.review_enrollment(p_membership uuid, p_approve boolean)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  m public.mission_memberships;
begin
  if auth.uid() is null then
    raise exception 'not authenticated' using errcode = '28000';
  end if;
  select * into m from public.mission_memberships where id = p_membership for update;
  if not found then
    raise exception 'enrollment request not found';
  end if;
  if not public.is_mission_admin(m.mission_id) then
    raise exception 'not authorized' using errcode = '42501';
  end if;
  if m.role <> 'missionary' or m.status <> 'pending' then
    raise exception 'request is not reviewable';
  end if;
  update public.mission_memberships
     set status = case when p_approve then 'verified' else 'rejected' end,
         verified_by = auth.uid(),
         verified_at = now()
   where id = m.id;
  insert into public.audit_log (mission_id, actor_id, action, target_id, details)
  values (m.mission_id, auth.uid(),
          case when p_approve then 'enrollment_approved' else 'enrollment_rejected' end,
          m.user_id, jsonb_build_object('membership_id', m.id));
end;
$$;

-- ───────────────────────── conversations & messages ─────────────────────────
create table public.conversations (
  id         uuid primary key default gen_random_uuid(),
  kind       text not null check (kind in ('direct', 'group')),
  title      text check (title is null or char_length(title) between 1 and 60),
  created_by uuid not null references public.profiles (id),
  created_at timestamptz not null default now(),
  check ((kind = 'group' and title is not null) or (kind = 'direct' and title is null))
);

create table public.conversation_members (
  conversation_id uuid not null references public.conversations (id) on delete cascade,
  user_id         uuid not null references public.profiles (id) on delete cascade,
  role            text not null default 'member' check (role in ('owner', 'member')),
  joined_at       timestamptz not null default now(),
  last_read_at    timestamptz not null default now(),
  primary key (conversation_id, user_id)
);
create index conversation_members_user_idx on public.conversation_members (user_id);

create table public.messages (
  id              uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations (id) on delete cascade,
  sender_id       uuid not null references public.profiles (id),
  body            text not null check (char_length(btrim(body)) between 1 and 4000),
  created_at      timestamptz not null default now()
);
create index messages_conversation_created_idx on public.messages (conversation_id, created_at);

-- One connection per pair of people, created only by accepting an invitation.
create table public.connections (
  user_a          uuid not null references public.profiles (id) on delete cascade,
  user_b          uuid not null references public.profiles (id) on delete cascade,
  conversation_id uuid not null references public.conversations (id) on delete cascade,
  created_at      timestamptz not null default now(),
  primary key (user_a, user_b),
  check (user_a < user_b)
);
create index connections_b_idx on public.connections (user_b);

create table public.invitations (
  id              uuid primary key default gen_random_uuid(),
  -- 80 bits of randomness from the server; clients cannot choose it (no INSERT grant on this column).
  code            text not null unique default substr(replace(gen_random_uuid()::text, '-', ''), 1, 20),
  created_by      uuid not null references public.profiles (id) on delete cascade,
  label           text check (label is null or char_length(label) <= 40),
  status          text not null default 'pending' check (status in ('pending', 'accepted', 'revoked')),
  expires_at      timestamptz not null default now() + interval '7 days',
  created_at      timestamptz not null default now(),
  accepted_by     uuid references public.profiles (id),
  accepted_at     timestamptz,
  conversation_id uuid references public.conversations (id)
);
create index invitations_created_by_idx on public.invitations (created_by);

-- ───────────────────────────── helper predicates ─────────────────────────────
create function public.is_member(p_conv uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.conversation_members
    where conversation_id = p_conv and user_id = auth.uid()
  );
$$;

create function public.shares_conversation(p_other uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.conversation_members a
    join public.conversation_members b using (conversation_id)
    where a.user_id = auth.uid() and b.user_id = p_other
  );
$$;

-- ───────────────────────────── RPCs ─────────────────────────────
-- What the person opening an invite link sees before accepting. Reveals only the inviter's name.
create function public.preview_invitation(p_code text)
returns table (inviter_name text, label text, valid boolean)
language sql
stable
security definer
set search_path = public
as $$
  select p.display_name, i.label,
         (i.status = 'pending' and i.expires_at > now() and i.created_by <> auth.uid())
  from public.invitations i
  join public.profiles p on p.id = i.created_by
  where i.code = lower(btrim(p_code)) and auth.uid() is not null;
$$;

create function public.accept_invitation(p_code text)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  me   uuid := auth.uid();
  inv  public.invitations;
  a    uuid;
  b    uuid;
  conv uuid;
begin
  if me is null then
    raise exception 'not authenticated' using errcode = '28000';
  end if;
  select * into inv from public.invitations where code = lower(btrim(p_code)) for update;
  if not found then
    raise exception 'invalid invitation';
  end if;
  if inv.status <> 'pending' or inv.expires_at <= now() then
    raise exception 'invitation is no longer valid';
  end if;
  if inv.created_by = me then
    raise exception 'you cannot accept your own invitation';
  end if;

  a := least(inv.created_by, me);
  b := greatest(inv.created_by, me);
  select conversation_id into conv from public.connections where user_a = a and user_b = b;

  if conv is null then
    insert into public.conversations (kind, created_by) values ('direct', inv.created_by)
      returning id into conv;
    insert into public.conversation_members (conversation_id, user_id)
      values (conv, inv.created_by), (conv, me);
    insert into public.connections (user_a, user_b, conversation_id) values (a, b, conv);
  end if;

  update public.invitations
     set status = 'accepted', accepted_by = me, accepted_at = now(), conversation_id = conv
   where id = inv.id;
  return conv;
end;
$$;

-- Group chat: creator may only add people they are already connected with.
create function public.create_group_chat(p_title text, p_member_ids uuid[])
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  me    uuid := auth.uid();
  t     text := btrim(coalesce(p_title, ''));
  ids   uuid[];
  m     uuid;
  conv  uuid;
begin
  if me is null then
    raise exception 'not authenticated' using errcode = '28000';
  end if;
  if char_length(t) < 1 or char_length(t) > 60 then
    raise exception 'group name must be 1-60 characters';
  end if;
  select coalesce(array_agg(distinct x), '{}') into ids
    from unnest(coalesce(p_member_ids, '{}')) as x where x <> me;
  if coalesce(array_length(ids, 1), 0) < 1 then
    raise exception 'choose at least one person';
  end if;
  if array_length(ids, 1) > 49 then
    raise exception 'a group can have at most 50 people';
  end if;
  foreach m in array ids loop
    if not exists (select 1 from public.connections
                    where user_a = least(me, m) and user_b = greatest(me, m)) then
      raise exception 'you are not connected with one of the selected people';
    end if;
  end loop;

  insert into public.conversations (kind, title, created_by) values ('group', t, me)
    returning id into conv;
  insert into public.conversation_members (conversation_id, user_id, role) values (conv, me, 'owner');
  insert into public.conversation_members (conversation_id, user_id)
    select conv, unnest(ids);
  return conv;
end;
$$;

create function public.add_group_member(p_conv uuid, p_user uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  me uuid := auth.uid();
begin
  if me is null then
    raise exception 'not authenticated' using errcode = '28000';
  end if;
  if not exists (select 1 from public.conversations c
                 join public.conversation_members cm on cm.conversation_id = c.id
                 where c.id = p_conv and c.kind = 'group' and cm.user_id = me and cm.role = 'owner') then
    raise exception 'only the group owner can add people';
  end if;
  if not exists (select 1 from public.connections
                  where user_a = least(me, p_user) and user_b = greatest(me, p_user)) then
    raise exception 'you are not connected with that person';
  end if;
  if exists (select 1 from public.conversation_members where conversation_id = p_conv and user_id = p_user) then
    raise exception 'already in this group';
  end if;
  if (select count(*) from public.conversation_members where conversation_id = p_conv) >= 50 then
    raise exception 'a group can have at most 50 people';
  end if;
  insert into public.conversation_members (conversation_id, user_id) values (p_conv, p_user);
end;
$$;

-- Leave a group. If the owner leaves, the longest-standing member becomes owner;
-- if nobody remains, the group is deleted.
create function public.leave_group(p_conv uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  me uuid := auth.uid();
  was_owner boolean;
  next_owner uuid;
begin
  if me is null then
    raise exception 'not authenticated' using errcode = '28000';
  end if;
  select cm.role = 'owner' into was_owner
    from public.conversation_members cm
    join public.conversations c on c.id = cm.conversation_id
   where cm.conversation_id = p_conv and cm.user_id = me and c.kind = 'group';
  if was_owner is null then
    raise exception 'you are not in this group';
  end if;
  delete from public.conversation_members where conversation_id = p_conv and user_id = me;
  select user_id into next_owner from public.conversation_members
   where conversation_id = p_conv order by joined_at, user_id limit 1;
  if next_owner is null then
    delete from public.conversations where id = p_conv;
  elsif was_owner then
    update public.conversation_members set role = 'owner'
     where conversation_id = p_conv and user_id = next_owner;
  end if;
end;
$$;

-- Server-clock read marker (SECURITY INVOKER: RLS + column grant apply).
create function public.mark_conversation_read(p_conv uuid)
returns void
language sql
security invoker
set search_path = public
as $$
  update public.conversation_members
     set last_read_at = now()
   where conversation_id = p_conv and user_id = auth.uid();
$$;

-- Inbox: one row per conversation I'm in (SECURITY INVOKER so RLS still applies).
create function public.list_my_conversations()
returns table (
  id uuid,
  kind text,
  title text,
  last_message_body text,
  last_message_at timestamptz,
  unread_count bigint,
  member_count bigint
)
language sql
stable
security invoker
set search_path = public
as $$
  select
    c.id,
    c.kind,
    case when c.kind = 'group'
         then coalesce(c.title, 'Group chat')
         else coalesce((select p.display_name
                          from public.conversation_members o
                          join public.profiles p on p.id = o.user_id
                         where o.conversation_id = c.id and o.user_id <> auth.uid()
                         limit 1), 'Conversation')
    end,
    lm.body,
    lm.created_at,
    (select count(*) from public.messages m
      where m.conversation_id = c.id and m.sender_id <> auth.uid() and m.created_at > me.last_read_at),
    (select count(*) from public.conversation_members x where x.conversation_id = c.id)
  from public.conversation_members me
  join public.conversations c on c.id = me.conversation_id
  left join lateral (
    select m.body, m.created_at from public.messages m
     where m.conversation_id = c.id order by m.created_at desc limit 1
  ) lm on true
  where me.user_id = auth.uid()
  order by coalesce(lm.created_at, c.created_at) desc;
$$;

-- ───────────────────────────── row level security ─────────────────────────────
alter table public.profiles             enable row level security;
alter table public.missions             enable row level security;
alter table public.mission_memberships  enable row level security;
alter table public.audit_log            enable row level security;
alter table public.conversations        enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages             enable row level security;
alter table public.connections          enable row level security;
alter table public.invitations          enable row level security;

create policy profiles_select on public.profiles for select to authenticated
  using (id = auth.uid() or public.shares_conversation(id));
create policy profiles_update_own on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());

create policy missions_select on public.missions for select to authenticated using (true);

create policy memberships_select on public.mission_memberships for select to authenticated
  using (user_id = auth.uid() or public.is_mission_admin(mission_id));
-- Only a *pending missionary* request about yourself; admin rows can never be self-created.
create policy memberships_request on public.mission_memberships for insert to authenticated
  with check (user_id = auth.uid() and role = 'missionary' and status = 'pending');

create policy audit_select on public.audit_log for select to authenticated
  using (public.is_mission_admin(mission_id));

create policy conversations_select on public.conversations for select to authenticated
  using (public.is_member(id));

create policy members_select on public.conversation_members for select to authenticated
  using (public.is_member(conversation_id));
create policy members_mark_read on public.conversation_members for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy messages_select on public.messages for select to authenticated
  using (public.is_member(conversation_id));
create policy messages_insert on public.messages for insert to authenticated
  with check (sender_id = auth.uid() and public.is_member(conversation_id));

create policy connections_select on public.connections for select to authenticated
  using (auth.uid() in (user_a, user_b));

create policy invitations_select on public.invitations for select to authenticated
  using (created_by = auth.uid());
create policy invitations_insert on public.invitations for insert to authenticated
  with check (created_by = auth.uid());
create policy invitations_revoke on public.invitations for update to authenticated
  using (created_by = auth.uid() and status = 'pending')
  with check (created_by = auth.uid() and status = 'revoked');

-- ───────────────────────────── grants (least privilege) ─────────────────────────────
revoke all on all tables    in schema public from anon, authenticated;
revoke all on all functions in schema public from public, anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;

grant usage on schema public to authenticated;

grant select                      on public.profiles, public.missions, public.mission_memberships,
                                      public.audit_log, public.conversations, public.conversation_members,
                                      public.messages, public.connections, public.invitations
                                  to authenticated;
grant update (display_name)       on public.profiles             to authenticated;
grant insert (user_id, mission_id, role) on public.mission_memberships to authenticated;
grant update (last_read_at)       on public.conversation_members to authenticated;
grant insert (id, conversation_id, sender_id, body) on public.messages to authenticated;
grant insert (created_by, label)  on public.invitations          to authenticated;
grant update (status)             on public.invitations          to authenticated;

grant execute on function
  public.is_mission_admin(uuid), public.is_member(uuid), public.shares_conversation(uuid),
  public.review_enrollment(uuid, boolean), public.preview_invitation(text),
  public.accept_invitation(text), public.create_group_chat(text, uuid[]),
  public.add_group_member(uuid, uuid), public.leave_group(uuid),
  public.mark_conversation_read(uuid), public.list_my_conversations()
  to authenticated;

-- ───────────────────────────── realtime ─────────────────────────────
-- Supabase Realtime (postgres_changes) respects the SELECT policies above.
do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    alter publication supabase_realtime add table public.messages;
    alter publication supabase_realtime add table public.conversation_members;
  end if;
end
$$;
