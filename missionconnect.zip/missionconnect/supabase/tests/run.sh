#!/usr/bin/env bash
# Runs the database tests against a THROWAWAY database on any PostgreSQL 14+ server you can
# create databases on (e.g. a local Postgres or a docker `postgres` container).
#
#   PGHOST=localhost PGPORT=5432 PGUSER=postgres PGPASSWORD=postgres ./supabase/tests/run.sh
#
# It creates database mc_test_<pid>, runs harness + migration + tests, then drops it.
# It also creates the cluster-wide roles `anon` and `authenticated` if missing.
# NEVER point this at a Supabase project database.
set -euo pipefail
cd "$(dirname "$0")"

DB="mc_test_$$"
psql -v ON_ERROR_STOP=1 -d postgres -qc "create database $DB"
cleanup() { psql -d postgres -qc "drop database if exists $DB" >/dev/null 2>&1 || true; }
trap cleanup EXIT

export PGDATABASE="$DB"
psql -v ON_ERROR_STOP=1 -q -f 00_harness.sql
psql -v ON_ERROR_STOP=1 -q -f ../migrations/0001_init.sql
psql -v ON_ERROR_STOP=1 -f 10_db_tests.sql 2>&1 | grep -E 'ok   -|FAIL|ERROR|ALL DATABASE TESTS PASSED' | sed 's/^psql:[^ ]* //'
