-- Database behaviour tests. Run via supabase/tests/run.sh (needs psql + a scratch Postgres).
-- Each assertion prints "ok" or aborts the whole script with FAIL.

\set ON_ERROR_STOP on
\set QUIET on
set client_min_messages = notice;

-- ───────── users (as superuser; the trigger creates profiles) ─────────
reset role;
insert into auth.users (id, email, raw_user_meta_data) values
  ('00000000-0000-0000-0000-00000000a001', 'alice@example.test', '{"display_name":"Alice Mom"}'),
  ('00000000-0000-0000-0000-00000000b002', 'bob@example.test',   '{"display_name":"Bob Elder","role":"admin","is_admin":true}'),
  ('00000000-0000-0000-0000-00000000c003', 'carol@example.test', '{"display_name":"Carol Sister"}'),
  ('00000000-0000-0000-0000-00000000d004', 'dave@example.test',  '{}'),
  ('00000000-0000-0000-0000-00000000e005', 'eve@example.test',   '{"display_name":"Eve Elder"}'),
  ('00000000-0000-0000-0000-00000000f006', 'pres@example.test',  '{"display_name":"President Fictional"}');

select t.ok((select count(*) from public.profiles) = 6, 'sign-up trigger created a profile for each user');
select t.ok((select display_name from public.profiles where id = '00000000-0000-0000-0000-00000000d004') = 'dave',
            'display name falls back to the email local-part');
select t.ok((select count(*) from public.mission_memberships) = 0,
            'client-supplied role metadata does not grant any role');

-- seed a verified admin for mission 1 (only possible outside RLS, e.g. SQL editor / service role)
insert into public.mission_memberships (user_id, mission_id, role, status, verified_at)
select '00000000-0000-0000-0000-00000000f006', id, 'admin', 'verified', now()
  from public.missions where name like 'Evergreen%';

-- shorthand: act as a user
\set alice '''00000000-0000-0000-0000-00000000a001'''
\set bob   '''00000000-0000-0000-0000-00000000b002'''
\set carol '''00000000-0000-0000-0000-00000000c003'''
\set dave  '''00000000-0000-0000-0000-00000000d004'''
\set eve   '''00000000-0000-0000-0000-00000000e005'''
\set pres  '''00000000-0000-0000-0000-00000000f006'''

-- ───────── anonymous access is closed ─────────
reset role; select set_config('request.jwt.claim.sub', '', false); set role anon;
select t.throws('select * from public.messages', 'anon cannot read messages', 'permission denied');
select t.throws('select * from public.profiles', 'anon cannot read profiles', 'permission denied');
select t.throws($$select public.accept_invitation('abc')$$, 'anon cannot call accept_invitation', 'permission denied');

-- ───────── invitations ─────────
reset role; select set_config('request.jwt.claim.sub', :alice, false); set role authenticated;
select t.throws($$insert into public.invitations (created_by, label, code) values (auth.uid(), 'Bob', 'aaaaaaaaaaaaaaaaaaaa')$$,
                'client cannot choose an invitation code', 'permission denied');
select t.throws($$insert into public.invitations (created_by, label) values ('00000000-0000-0000-0000-00000000b002', 'x')$$,
                'cannot create an invitation as someone else', 'row-level security');
insert into public.invitations (created_by, label) values (auth.uid(), 'Bob (missionary)');
select t.ok((select count(*) from public.invitations) = 1, 'alice created an invitation and can see it');
select t.ok((select length(code) from public.invitations) = 20, 'server generated a 20-char code');
select code as alice_code from public.invitations limit 1 \gset

reset role; select set_config('request.jwt.claim.sub', :bob, false); set role authenticated;
select t.ok((select count(*) from public.invitations) = 0, 'bob cannot list alice''s invitations');
select t.ok((select inviter_name from public.preview_invitation(:'alice_code')) = 'Alice Mom', 'bob can preview the invite');
select t.ok((select valid from public.preview_invitation(:'alice_code')), 'preview says valid');
select t.throws($$select public.accept_invitation('does-not-exist')$$, 'unknown code rejected', 'invalid invitation');
select public.accept_invitation(:'alice_code') as ab_conv \gset
select t.ok(:'ab_conv' is not null, 'bob accepted the invitation and got a conversation');
select t.ok((select count(*) from public.connections) = 1, 'a connection exists');
select t.ok((select count(*) from public.conversation_members where conversation_id = :'ab_conv') = 2, 'both people are members');
select t.throws(format($$select public.accept_invitation(%L)$$, :'alice_code'), 'invitation cannot be used twice', 'no longer valid');

reset role; select set_config('request.jwt.claim.sub', :carol, false); set role authenticated;
select t.throws(format($$select public.accept_invitation(%L)$$, :'alice_code'), 'third person cannot reuse the code', 'no longer valid');

-- own invitation, revoked, expired
reset role; select set_config('request.jwt.claim.sub', :alice, false); set role authenticated;
insert into public.invitations (created_by, label) values (auth.uid(), 'self');
select code as self_code from public.invitations where label = 'self' \gset
select t.throws(format($$select public.accept_invitation(%L)$$, :'self_code'), 'cannot accept own invitation', 'own invitation');
select t.throws($$update public.invitations set status = 'accepted' where label = 'self'$$, 'owner cannot mark an invitation accepted', 'row-level security');
update public.invitations set status = 'revoked' where code = :'self_code';
select t.ok((select status from public.invitations where code = :'self_code') = 'revoked', 'owner can revoke a pending invitation');
insert into public.invitations (created_by, label) values (auth.uid(), 'for carol');
select code as carol_code from public.invitations where label = 'for carol' \gset

reset role; select set_config('request.jwt.claim.sub', :carol, false); set role authenticated;
select t.throws(format($$select public.accept_invitation(%L)$$, :'self_code'), 'revoked invitation rejected', 'no longer valid');
reset role; update public.invitations set expires_at = now() - interval '1 minute' where label = 'for carol';
select set_config('request.jwt.claim.sub', :carol, false); set role authenticated;
select t.throws(format($$select public.accept_invitation(%L)$$, :'carol_code'), 'expired invitation rejected', 'no longer valid');
reset role; update public.invitations set expires_at = now() + interval '1 day' where label = 'for carol';
select set_config('request.jwt.claim.sub', :carol, false); set role authenticated;
select public.accept_invitation(:'carol_code') as ac_conv \gset
select t.ok(:'ac_conv' <> :'ab_conv', 'carol connected to alice in a separate conversation');

-- ───────── direct messaging ─────────
reset role; select set_config('request.jwt.claim.sub', :alice, false); set role authenticated;
insert into public.messages (conversation_id, sender_id, body) values (:'ab_conv', auth.uid(), 'Hi Bob! Love you.');
select t.throws(format($$insert into public.messages (conversation_id, sender_id, body) values (%L, '00000000-0000-0000-0000-00000000b002', 'spoof')$$, :'ab_conv'),
                'cannot send as another user', 'row-level security');
select t.throws(format($$insert into public.messages (conversation_id, sender_id, body) values (%L, auth.uid(), '   ')$$, :'ab_conv'),
                'blank message rejected', 'check constraint');
select t.throws(format($$insert into public.messages (conversation_id, sender_id, body) values (%L, auth.uid(), repeat('x', 4001))$$, :'ab_conv'),
                'over-long message rejected', 'check constraint');
select t.throws($$update public.messages set body = 'edited'$$, 'messages cannot be edited by clients', 'permission denied');
select t.throws($$delete from public.messages$$, 'messages cannot be deleted by clients', 'permission denied');
select t.throws(format($$insert into public.messages (conversation_id, sender_id, body, created_at) values (%L, auth.uid(), 'backdated', '2000-01-01')$$, :'ab_conv'),
                'clients cannot set created_at', 'permission denied');

reset role; select set_config('request.jwt.claim.sub', :bob, false); set role authenticated;
select t.ok((select count(*) from public.messages where conversation_id = :'ab_conv') = 1, 'bob sees alice''s message');
insert into public.messages (conversation_id, sender_id, body) values (:'ab_conv', auth.uid(), 'Hi Mom!');
select t.ok((select unread_count from public.list_my_conversations() where id = :'ab_conv') = 1, 'bob has 1 unread');
select public.mark_conversation_read(:'ab_conv');
select t.ok((select unread_count from public.list_my_conversations() where id = :'ab_conv') = 0, 'mark read clears unread');
select t.ok((select title from public.list_my_conversations() where id = :'ab_conv') = 'Alice Mom', 'direct chat is titled with the other person');

reset role; select set_config('request.jwt.claim.sub', :carol, false); set role authenticated;
select t.ok((select count(*) from public.messages where conversation_id = :'ab_conv') = 0, 'carol cannot read alice/bob messages');
select t.throws(format($$insert into public.messages (conversation_id, sender_id, body) values (%L, auth.uid(), 'sneaky')$$, :'ab_conv'),
                'non-member cannot post', 'row-level security');
select t.ok((select count(*) from public.profiles where id = '00000000-0000-0000-0000-00000000b002') = 0, 'carol cannot see bob''s profile (no shared chat)');
select t.ok((select count(*) from public.profiles where id = '00000000-0000-0000-0000-00000000a001') = 1, 'carol can see alice''s profile (shared chat)');
-- updating someone else's profile silently matches zero rows (RLS), and the name is unchanged
update public.profiles set display_name = 'hacked' where id = '00000000-0000-0000-0000-00000000a001';
reset role;
select t.ok((select display_name from public.profiles where id = '00000000-0000-0000-0000-00000000a001') = 'Alice Mom',
            'cannot rename another user');

-- ───────── family group chat ─────────
-- alice is connected to bob and carol; dave is a stranger
select set_config('request.jwt.claim.sub', :alice, false); set role authenticated;
select t.throws(format($$select public.create_group_chat('Family', array[%L::uuid, '00000000-0000-0000-0000-00000000d004'::uuid])$$,
                       '00000000-0000-0000-0000-00000000b002'),
                'cannot add a person you are not connected with', 'not connected');
select t.throws($$select public.create_group_chat('  ', array['00000000-0000-0000-0000-00000000b002'::uuid])$$,
                'group needs a name', 'group name');
select t.throws($$select public.create_group_chat('Solo', '{}'::uuid[])$$, 'group needs at least one other person', 'at least one');
select public.create_group_chat('Family', array['00000000-0000-0000-0000-00000000b002'::uuid, '00000000-0000-0000-0000-00000000c003'::uuid]) as fam \gset
select t.ok((select count(*) from public.conversation_members where conversation_id = :'fam') = 3, 'group has alice, bob, carol');
select t.ok((select role from public.conversation_members where conversation_id = :'fam' and user_id = auth.uid()) = 'owner', 'creator is owner');
select t.ok((select member_count from public.list_my_conversations() where id = :'fam') = 3, 'inbox reports 3 members');
insert into public.messages (conversation_id, sender_id, body) values (:'fam', auth.uid(), 'Family group is live');

reset role; select set_config('request.jwt.claim.sub', :bob, false); set role authenticated;
select t.ok((select count(*) from public.messages where conversation_id = :'fam') = 1, 'bob sees the group message');
select t.ok((select count(*) from public.profiles where id = '00000000-0000-0000-0000-00000000c003') = 1,
            'bob can now see carol''s profile through the group');
insert into public.messages (conversation_id, sender_id, body) values (:'fam', auth.uid(), 'Love you all');
select t.throws(format($$select public.add_group_member(%L, '00000000-0000-0000-0000-00000000d004')$$, :'fam'),
                'non-owner cannot add members', 'only the group owner');

reset role; select set_config('request.jwt.claim.sub', :carol, false); set role authenticated;
select t.ok((select count(*) from public.messages where conversation_id = :'fam') = 2, 'carol sees both group messages');
select t.ok((select unread_count from public.list_my_conversations() where id = :'fam') = 2, 'carol has 2 unread in the group');

reset role; select set_config('request.jwt.claim.sub', :dave, false); set role authenticated;
select t.ok((select count(*) from public.messages) = 0, 'dave sees no messages at all');
select t.ok((select count(*) from public.conversations) = 0, 'dave sees no conversations');
select t.throws(format($$insert into public.conversation_members (conversation_id, user_id) values (%L, auth.uid())$$, :'fam'),
                'cannot add yourself to a chat directly', 'permission denied');

reset role; select set_config('request.jwt.claim.sub', :alice, false); set role authenticated;
select t.throws(format($$select public.add_group_member(%L, '00000000-0000-0000-0000-00000000d004')$$, :'fam'),
                'owner cannot add an unconnected person', 'not connected');
select t.throws(format($$select public.add_group_member(%L, '00000000-0000-0000-0000-00000000b002')$$, :'fam'),
                'cannot add someone twice', 'already in this group');

-- carol leaves; she loses access; ownership transfers when the owner leaves
reset role; select set_config('request.jwt.claim.sub', :carol, false); set role authenticated;
select public.leave_group(:'fam');
select t.ok((select count(*) from public.messages where conversation_id = :'fam') = 0, 'carol loses access after leaving');
reset role; select set_config('request.jwt.claim.sub', :alice, false); set role authenticated;
select public.leave_group(:'fam');
reset role;
select t.ok((select role from public.conversation_members where conversation_id = :'fam' and user_id = '00000000-0000-0000-0000-00000000b002') = 'owner',
            'ownership passes to the remaining member');

-- ───────── verified roles cannot be self-granted ─────────
select set_config('request.jwt.claim.sub', :eve, false); set role authenticated;
select t.throws($$insert into public.mission_memberships (user_id, mission_id, role) select auth.uid(), id, 'admin' from public.missions limit 1$$,
                'cannot request admin role', 'row-level security');
select t.throws($$insert into public.mission_memberships (user_id, mission_id, role, status) select auth.uid(), id, 'missionary', 'verified' from public.missions limit 1$$,
                'cannot self-verify', 'permission denied');
insert into public.mission_memberships (user_id, mission_id, role)
  select auth.uid(), id, 'missionary' from public.missions where name like 'Evergreen%';
select t.ok((select status from public.mission_memberships) = 'pending', 'eve''s missionary request is pending');
select t.throws($$update public.mission_memberships set status = 'verified'$$, 'cannot update own status', 'permission denied');
select mm.id as eve_req from public.mission_memberships mm limit 1 \gset
select t.throws(format($$select public.review_enrollment(%L, true)$$, :'eve_req'), 'non-admin cannot approve', 'not authorized');
select t.ok((select count(*) from public.audit_log) = 0, 'non-admin cannot read the audit log');

reset role; select set_config('request.jwt.claim.sub', :bob, false); set role authenticated;
select t.ok((select count(*) from public.mission_memberships) = 0, 'unrelated user cannot see enrollment requests');

reset role; select set_config('request.jwt.claim.sub', :pres, false); set role authenticated;
select t.ok((select count(*) from public.mission_memberships where status = 'pending') = 1, 'verified admin sees the pending request');
select public.review_enrollment(:'eve_req', true);
select t.ok((select status from public.mission_memberships where id = :'eve_req') = 'verified', 'admin approved the missionary');
select t.ok((select count(*) from public.audit_log where action = 'enrollment_approved') = 1, 'approval was written to the audit log');
select t.throws(format($$select public.review_enrollment(%L, false)$$, :'eve_req'), 'a decided request cannot be re-reviewed', 'not reviewable');
select t.throws($$delete from public.audit_log$$, 'audit log is append-only for clients', 'permission denied');

reset role;
select set_config('request.jwt.claim.sub', '', false);
\echo ALL DATABASE TESTS PASSED
