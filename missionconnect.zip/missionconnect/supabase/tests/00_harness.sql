-- Test harness: lets the real migration run on a plain PostgreSQL 14+ server by stubbing the
-- few Supabase pieces it depends on (auth schema, auth.uid(), anon/authenticated roles).
-- Do NOT run this against a real Supabase project.

do $$
begin
  if not exists (select 1 from pg_roles where rolname = 'anon') then
    create role anon nologin;
  end if;
  if not exists (select 1 from pg_roles where rolname = 'authenticated') then
    create role authenticated nologin;
  end if;
end
$$;

create schema if not exists auth;
create table if not exists auth.users (
  id                 uuid primary key default gen_random_uuid(),
  email              text,
  raw_user_meta_data jsonb not null default '{}'::jsonb
);
create or replace function auth.uid() returns uuid
language sql stable as $$
  select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid
$$;
grant usage on schema auth to anon, authenticated;
grant execute on function auth.uid() to anon, authenticated;

-- Assertion helpers (usable while impersonating a role)
create schema if not exists t;
grant usage on schema t to anon, authenticated;

create or replace function t.ok(cond boolean, msg text) returns void
language plpgsql as $$
begin
  if cond is not true then
    raise exception 'FAIL: %', msg;
  end if;
  raise notice 'ok   - %', msg;
end;
$$;

-- Passes only if the statement raises an error (optionally matching a message fragment).
create or replace function t.throws(stmt text, msg text, fragment text default null) returns void
language plpgsql as $$
declare
  err text;
begin
  begin
    execute stmt;
  exception when others then
    err := sqlerrm;
  end;
  if err is null then
    raise exception 'FAIL: % (statement succeeded but should have failed)', msg;
  end if;
  if fragment is not null and position(lower(fragment) in lower(err)) = 0 then
    raise exception 'FAIL: % (wrong error: %)', msg, err;
  end if;
  raise notice 'ok   - % [%]', msg, err;
end;
$$;

-- Number of rows visible to the current role for a query.
create or replace function t.count(q text) returns bigint
language plpgsql as $$
declare n bigint;
begin
  execute 'select count(*) from (' || q || ') s' into n;
  return n;
end;
$$;

grant execute on all functions in schema t to anon, authenticated;
