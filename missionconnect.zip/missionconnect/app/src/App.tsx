import { useState } from 'react';
import { AuthProvider, useAuth } from './auth/AuthContext.tsx';
import { AuthScreen } from './components/AuthScreen.tsx';
import { AcceptInvite } from './components/AcceptInvite.tsx';
import { Shell } from './components/Shell.tsx';
import { Disclaimer } from './components/Disclaimer.tsx';
import { extractInviteCode } from './lib/invite.ts';
import { supabaseConfigured } from './lib/supabase.ts';

const INVITE_KEY = 'mc_pending_invite';

/** Pick up ?invite=CODE from the URL once, remember it across sign-up/sign-in, then clean the URL. */
function readPendingInvite(): string | null {
  let fromUrl: string | null = null;
  try {
    const raw = new URL(window.location.href).searchParams.get('invite');
    fromUrl = raw ? extractInviteCode(raw) : null;
    if (raw) {
      const clean = new URL(window.location.href);
      clean.searchParams.delete('invite');
      window.history.replaceState({}, '', clean.pathname + clean.search + clean.hash);
    }
  } catch {
    /* ignore */
  }
  try {
    if (fromUrl) {
      localStorage.setItem(INVITE_KEY, fromUrl);
      return fromUrl;
    }
    return localStorage.getItem(INVITE_KEY);
  } catch {
    return fromUrl;
  }
}

function clearPendingInvite() {
  try {
    localStorage.removeItem(INVITE_KEY);
  } catch {
    /* ignore */
  }
}

function SetupNotice() {
  return (
    <main className="center-card">
      <h1>MissionConnect</h1>
      <p>
        This app needs a Supabase project. Copy <code>app/.env.example</code> to <code>app/.env.local</code>, fill in{' '}
        <code>VITE_SUPABASE_URL</code> and <code>VITE_SUPABASE_ANON_KEY</code>, apply{' '}
        <code>supabase/migrations/0001_init.sql</code>, then restart <code>npm run dev</code>.
      </p>
      <p className="muted">Full steps are in the README.</p>
    </main>
  );
}

function Gate() {
  const { loading, session, profile } = useAuth();
  const [pendingInvite, setPendingInvite] = useState<string | null>(readPendingInvite);
  const [openConversation, setOpenConversation] = useState<string | null>(null);

  if (loading) return <div className="center-card" role="status">Loading…</div>;
  if (!session) return <AuthScreen invitePending={pendingInvite !== null} />;
  if (!profile) return <div className="center-card" role="status">Loading your profile…</div>;

  if (pendingInvite) {
    return (
      <main className="center-card">
        <AcceptInvite
          code={pendingInvite}
          onDone={(conversationId) => {
            clearPendingInvite();
            setPendingInvite(null);
            setOpenConversation(conversationId);
          }}
          onCancel={() => {
            clearPendingInvite();
            setPendingInvite(null);
          }}
        />
      </main>
    );
  }
  return <Shell initialConversationId={openConversation} />;
}

export default function App() {
  if (!supabaseConfigured) return <SetupNotice />;
  return (
    <AuthProvider>
      <div className="app">
        <Gate />
        <Disclaimer />
      </div>
    </AuthProvider>
  );
}
