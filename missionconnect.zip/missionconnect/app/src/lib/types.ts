export interface Profile {
  id: string;
  display_name: string;
}

export interface ConversationSummary {
  id: string;
  kind: 'direct' | 'group';
  title: string;
  last_message_body: string | null;
  last_message_at: string | null;
  unread_count: number;
  member_count: number;
}

export interface Message {
  id: string;
  conversation_id: string;
  sender_id: string;
  body: string;
  created_at: string;
  /** client-only: shown while the insert is in flight */
  pending?: boolean;
  /** client-only: the insert failed and can be retried */
  failed?: boolean;
}

export interface Invitation {
  id: string;
  code: string;
  label: string | null;
  status: 'pending' | 'accepted' | 'revoked';
  expires_at: string;
  created_at: string;
}

export interface Person {
  userId: string;
  name: string;
  conversationId: string;
}

export interface Member {
  userId: string;
  name: string;
  role: 'owner' | 'member';
}
