import type { Message } from './types.ts';

export const MAX_MESSAGE_LENGTH = 4000;

export type BodyCheck = { ok: true; body: string } | { ok: false; error: string };

/** Mirrors the database CHECK (1–4000 chars after trimming) so users get a friendly error first. */
export function validateBody(raw: string): BodyCheck {
  const body = raw.trim();
  if (body.length === 0) return { ok: false, error: 'Type a message first.' };
  if (body.length > MAX_MESSAGE_LENGTH) {
    return { ok: false, error: `Messages can be at most ${MAX_MESSAGE_LENGTH} characters.` };
  }
  return { ok: true, body };
}

function byTimeThenId(a: Message, b: Message): number {
  const d = Date.parse(a.created_at) - Date.parse(b.created_at);
  if (d !== 0) return d;
  return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
}

/**
 * Merge incoming messages into the list. De-duplicates by id (so a realtime echo of a message
 * we already added optimistically does not appear twice), lets the incoming copy win (so the
 * server version replaces the pending one), and keeps chronological order.
 */
export function mergeMessages(existing: readonly Message[], incoming: readonly Message[]): Message[] {
  const byId = new Map<string, Message>();
  for (const m of existing) byId.set(m.id, m);
  for (const m of incoming) byId.set(m.id, m);
  return [...byId.values()].sort(byTimeThenId);
}

export function markFailed(messages: readonly Message[], id: string): Message[] {
  return messages.map((m) => (m.id === id ? { ...m, pending: false, failed: true } : m));
}

export function markPending(messages: readonly Message[], id: string): Message[] {
  return messages.map((m) => (m.id === id ? { ...m, pending: true, failed: false } : m));
}

export function previewText(body: string | null, max = 60): string {
  if (!body) return 'No messages yet';
  const oneLine = body.replace(/\s+/g, ' ').trim();
  return oneLine.length <= max ? oneLine : `${oneLine.slice(0, max - 1)}…`;
}
