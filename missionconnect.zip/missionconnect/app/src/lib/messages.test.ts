import { test } from 'node:test';
import assert from 'node:assert/strict';
import { MAX_MESSAGE_LENGTH, markFailed, markPending, mergeMessages, previewText, validateBody } from './messages.ts';
import type { Message } from './types.ts';

const msg = (id: string, at: string, extra: Partial<Message> = {}): Message => ({
  id,
  conversation_id: 'c1',
  sender_id: 'u1',
  body: `body-${id}`,
  created_at: at,
  ...extra,
});

test('validateBody trims and accepts normal text', () => {
  assert.deepEqual(validateBody('  hello  '), { ok: true, body: 'hello' });
});

test('validateBody rejects blank and whitespace-only input', () => {
  assert.equal(validateBody('').ok, false);
  assert.equal(validateBody(' \n\t ').ok, false);
});

test('validateBody enforces the 4000 character limit', () => {
  assert.equal(validateBody('x'.repeat(MAX_MESSAGE_LENGTH)).ok, true);
  assert.equal(validateBody('x'.repeat(MAX_MESSAGE_LENGTH + 1)).ok, false);
});

test('mergeMessages de-duplicates by id and the incoming copy wins', () => {
  const pending = msg('a', '2026-10-14T20:00:00.000Z', { pending: true });
  const confirmed = msg('a', '2026-10-14T20:00:01.000Z');
  const merged = mergeMessages([pending], [confirmed]);
  assert.equal(merged.length, 1);
  assert.equal(merged[0]!.pending, undefined);
  assert.equal(merged[0]!.created_at, '2026-10-14T20:00:01.000Z');
});

test('mergeMessages keeps chronological order regardless of arrival order', () => {
  const merged = mergeMessages([msg('c', '2026-10-14T20:00:03Z')], [msg('a', '2026-10-14T20:00:01Z'), msg('b', '2026-10-14T20:00:02Z')]);
  assert.deepEqual(merged.map((m) => m.id), ['a', 'b', 'c']);
});

test('mergeMessages breaks timestamp ties deterministically by id', () => {
  const t = '2026-10-14T20:00:00Z';
  assert.deepEqual(mergeMessages([], [msg('b', t), msg('a', t)]).map((m) => m.id), ['a', 'b']);
});

test('mergeMessages does not mutate its inputs', () => {
  const existing = [msg('a', '2026-10-14T20:00:00Z')];
  const incoming = [msg('b', '2026-10-14T20:00:01Z')];
  mergeMessages(existing, incoming);
  assert.equal(existing.length, 1);
  assert.equal(incoming.length, 1);
});

test('markFailed / markPending flip only the targeted message', () => {
  const list = [msg('a', '2026-10-14T20:00:00Z', { pending: true }), msg('b', '2026-10-14T20:00:01Z', { pending: true })];
  const failed = markFailed(list, 'a');
  assert.deepEqual([failed[0]!.failed, failed[0]!.pending, failed[1]!.pending], [true, false, true]);
  const retried = markPending(failed, 'a');
  assert.deepEqual([retried[0]!.failed, retried[0]!.pending], [false, true]);
});

test('previewText collapses whitespace and truncates', () => {
  assert.equal(previewText(null), 'No messages yet');
  assert.equal(previewText('a\n\n  b'), 'a b');
  const long = previewText('x'.repeat(100), 20);
  assert.equal(long.length, 20);
  assert.ok(long.endsWith('…'));
});
