import { db } from './supabase.ts';
import type { Person } from './types.ts';

/** People I'm connected to (via accepted invitations), with the conversation I share with each. */
export async function fetchConnections(me: string): Promise<Person[]> {
  const { data, error } = await db()
    .from('connections')
    .select('user_a, user_b, conversation_id');
  if (error) throw error;

  const rows = (data ?? []) as { user_a: string; user_b: string; conversation_id: string }[];
  if (rows.length === 0) return [];

  const otherOf = (r: { user_a: string; user_b: string }) => (r.user_a === me ? r.user_b : r.user_a);
  const { data: profiles, error: pErr } = await db()
    .from('profiles')
    .select('id, display_name')
    .in('id', rows.map(otherOf));
  if (pErr) throw pErr;

  const names = new Map<string, string>(
    ((profiles ?? []) as { id: string; display_name: string }[]).map((p) => [p.id, p.display_name]),
  );
  return rows
    .map((r) => ({ userId: otherOf(r), name: names.get(otherOf(r)) ?? 'Unknown', conversationId: r.conversation_id }))
    .sort((a, b) => a.name.localeCompare(b.name));
}
