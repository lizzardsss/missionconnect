import { test } from 'node:test';
import assert from 'node:assert/strict';
import { buildInviteLink, extractInviteCode } from './invite.ts';

const CODE = '0123456789abcdef0123';

test('extractInviteCode accepts a bare code, any case, with whitespace', () => {
  assert.equal(extractInviteCode(CODE), CODE);
  assert.equal(extractInviteCode(`  ${CODE.toUpperCase()}\n`), CODE);
});

test('extractInviteCode reads the code out of an invite link', () => {
  assert.equal(extractInviteCode(`https://example.test/?invite=${CODE}`), CODE);
  assert.equal(extractInviteCode(`http://localhost:5173/?foo=1&invite=${CODE}#x`), CODE);
});

test('extractInviteCode rejects junk, wrong lengths and non-hex', () => {
  assert.equal(extractInviteCode(''), null);
  assert.equal(extractInviteCode('hello'), null);
  assert.equal(extractInviteCode(CODE.slice(1)), null);
  assert.equal(extractInviteCode(`${CODE}0`), null);
  assert.equal(extractInviteCode('g'.repeat(20)), null);
  assert.equal(extractInviteCode('https://example.test/?invite=nope'), null);
  assert.equal(extractInviteCode('https://example.test/'), null);
});

test('buildInviteLink round-trips through extractInviteCode', () => {
  const link = buildInviteLink('https://example.test/', CODE);
  assert.equal(link, `https://example.test/?invite=${CODE}`);
  assert.equal(extractInviteCode(link), CODE);
});
