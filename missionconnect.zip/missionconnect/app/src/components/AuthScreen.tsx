import { useState, type FormEvent } from 'react';
import { db, errMsg } from '../lib/supabase.ts';

type Mode = 'signin' | 'signup';

export function AuthScreen({ invitePending }: { invitePending: boolean }) {
  const [mode, setMode] = useState<Mode>(invitePending ? 'signup' : 'signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setNotice(null);
    if (mode === 'signup') {
      if (name.trim().length === 0) return setError('Please enter your name.');
      if (password.length < 8) return setError('Use a password with at least 8 characters.');
    }
    setBusy(true);
    try {
      if (mode === 'signup') {
        const { data, error: err } = await db().auth.signUp({
          email: email.trim(),
          password,
          // Only the display name is sent. Roles are never accepted from the browser.
          options: { data: { display_name: name.trim() }, emailRedirectTo: window.location.origin },
        });
        if (err) throw err;
        if (!data.session) setNotice('Account created. Check your email to confirm your address, then sign in.');
      } else {
        const { error: err } = await db().auth.signInWithPassword({ email: email.trim(), password });
        if (err) throw err;
      }
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="center-card">
      <h1>MissionConnect</h1>
      <p className="muted">One place for families and missionaries to stay in touch.</p>
      {invitePending && (
        <p className="banner" role="note">
          You have a private invitation waiting. {mode === 'signup' ? 'Create an account' : 'Sign in'} to view it.
        </p>
      )}

      <form onSubmit={submit} className="stack">
        {mode === 'signup' && (
          <label>
            Your name
            <input value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" maxLength={60} required />
          </label>
        )}
        <label>
          Email
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" required />
        </label>
        <label>
          Password
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete={mode === 'signup' ? 'new-password' : 'current-password'}
            minLength={mode === 'signup' ? 8 : undefined}
            required
          />
        </label>
        {error && <p className="error" role="alert">{error}</p>}
        {notice && <p className="success" role="status">{notice}</p>}
        <button className="primary" type="submit" disabled={busy}>
          {busy ? 'Please wait…' : mode === 'signup' ? 'Create account' : 'Sign in'}
        </button>
      </form>

      <button
        className="link"
        type="button"
        onClick={() => {
          setMode(mode === 'signup' ? 'signin' : 'signup');
          setError(null);
          setNotice(null);
        }}
      >
        {mode === 'signup' ? 'Already have an account? Sign in' : 'New here? Create an account'}
      </button>
      {mode === 'signup' && (
        <p className="muted small">
          Missionary and administrator access is granted only after verification — it cannot be chosen at sign-up.
        </p>
      )}
    </main>
  );
}
