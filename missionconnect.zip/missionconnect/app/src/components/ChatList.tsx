import { useCallback, useEffect, useState } from 'react';
import { useAuth } from '../auth/AuthContext.tsx';
import { db, errMsg } from '../lib/supabase.ts';
import { previewText } from '../lib/messages.ts';
import type { ConversationSummary } from '../lib/types.ts';

interface Props {
  activeId: string | null;
  onSelect: (id: string) => void;
  onNewGroup: () => void;
  reloadKey: number;
}

export function ChatList({ activeId, onSelect, onNewGroup, reloadKey }: Props) {
  const { user } = useAuth();
  const [items, setItems] = useState<ConversationSummary[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    const { data, error: err } = await db().rpc('list_my_conversations');
    if (err) {
      setError(errMsg(err));
      return;
    }
    setError(null);
    setItems((data ?? []) as ConversationSummary[]);
  }, []);

  useEffect(() => {
    void load();
  }, [load, reloadKey]);

  // Live inbox: refresh when a message arrives in any of my chats or I'm added to a chat.
  // Realtime only delivers rows the signed-in user is allowed to SELECT (row level security).
  useEffect(() => {
    if (!user) return;
    const channel = db()
      .channel(`inbox:${user.id}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, () => void load())
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'conversation_members', filter: `user_id=eq.${user.id}` },
        () => void load(),
      )
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') void load(); // catch up after (re)connecting
      });
    return () => {
      void db().removeChannel(channel);
    };
  }, [user, load]);

  return (
    <div className="chat-list">
      <div className="list-head">
        <h2>Chats</h2>
        <button onClick={onNewGroup}>New family group</button>
      </div>
      {error && <p className="error" role="alert">{error}</p>}
      {items === null && !error && <p className="muted" role="status">Loading…</p>}
      {items?.length === 0 && (
        <p className="muted">No conversations yet. Invite a family member or missionary from “Family &amp; invitations”.</p>
      )}
      <ul>
        {items?.map((c) => (
          <li key={c.id}>
            <button className={c.id === activeId ? 'chat-row active' : 'chat-row'} onClick={() => onSelect(c.id)}>
              <span className="avatar" aria-hidden="true">{c.kind === 'group' ? '👪' : c.title.slice(0, 1).toUpperCase()}</span>
              <span className="chat-row-main">
                <span className="chat-row-title">
                  {c.title}
                  {c.kind === 'group' && <span className="muted small"> · {c.member_count} people</span>}
                </span>
                <span className="chat-row-preview">{previewText(c.last_message_body)}</span>
              </span>
              {c.unread_count > 0 && <span className="badge" aria-label={`${c.unread_count} unread`}>{c.unread_count}</span>}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
