import { useState } from 'react';
import { useAuth } from '../auth/AuthContext.tsx';
import { ChatList } from './ChatList.tsx';
import { ChatView } from './ChatView.tsx';
import { PeoplePanel } from './PeoplePanel.tsx';
import { NewGroupModal } from './NewGroupModal.tsx';

type Tab = 'chats' | 'people';

export function Shell({ initialConversationId }: { initialConversationId: string | null }) {
  const { profile, signOut } = useAuth();
  const [tab, setTab] = useState<Tab>('chats');
  const [activeId, setActiveId] = useState<string | null>(initialConversationId);
  const [reloadKey, setReloadKey] = useState(0);
  const [showGroup, setShowGroup] = useState(false);

  const bump = () => setReloadKey((k) => k + 1);
  const openConversation = (id: string) => {
    setActiveId(id);
    setTab('chats');
    bump();
  };

  return (
    <div className={`shell${activeId && tab === 'chats' ? ' has-active' : ''}`}>
      <header className="topbar">
        <strong>MissionConnect</strong>
        <span className="topbar-user">
          {profile?.display_name}
          <button className="link" onClick={() => void signOut()}>Sign out</button>
        </span>
      </header>

      <nav className="tabs" aria-label="Sections">
        <button className={tab === 'chats' ? 'tab active' : 'tab'} onClick={() => setTab('chats')} aria-current={tab === 'chats'}>
          Chats
        </button>
        <button className={tab === 'people' ? 'tab active' : 'tab'} onClick={() => setTab('people')} aria-current={tab === 'people'}>
          Family &amp; invitations
        </button>
      </nav>

      {tab === 'chats' ? (
        <div className="split">
          <aside className="pane list-pane">
            <ChatList activeId={activeId} onSelect={setActiveId} onNewGroup={() => setShowGroup(true)} reloadKey={reloadKey} />
          </aside>
          <section className="pane chat-pane">
            {activeId ? (
              <ChatView
                key={activeId}
                conversationId={activeId}
                onBack={() => setActiveId(null)}
                onChanged={bump}
                onLeft={() => {
                  setActiveId(null);
                  bump();
                }}
              />
            ) : (
              <div className="empty">
                <p>Select a conversation, or open “Family &amp; invitations” to invite someone.</p>
              </div>
            )}
          </section>
        </div>
      ) : (
        <div className="pane people-pane">
          <PeoplePanel onOpenChat={openConversation} onNewGroup={() => setShowGroup(true)} />
        </div>
      )}

      {showGroup && (
        <NewGroupModal
          onClose={() => setShowGroup(false)}
          onCreated={(id) => {
            setShowGroup(false);
            openConversation(id);
          }}
        />
      )}
    </div>
  );
}
