import { useCallback, useEffect, useRef, useState, type FormEvent, type KeyboardEvent } from 'react';
import { useAuth } from '../auth/AuthContext.tsx';
import { db, errMsg } from '../lib/supabase.ts';
import { fetchConnections } from '../lib/api.ts';
import { markFailed, markPending, mergeMessages, validateBody, MAX_MESSAGE_LENGTH } from '../lib/messages.ts';
import type { Member, Message, Person } from '../lib/types.ts';

interface Props {
  conversationId: string;
  onBack: () => void;
  onChanged: () => void;
  onLeft: () => void;
}

type Live = 'connecting' | 'live' | 'offline';

const MESSAGE_COLUMNS = 'id, conversation_id, sender_id, body, created_at';

function timeLabel(iso: string): string {
  const d = new Date(iso);
  const sameDay = d.toDateString() === new Date().toDateString();
  return sameDay
    ? d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })
    : d.toLocaleDateString([], { month: 'short', day: 'numeric' }) +
        ' ' +
        d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}

export function ChatView({ conversationId, onBack, onChanged, onLeft }: Props) {
  const { user } = useAuth();
  const me = user!.id;

  const [kind, setKind] = useState<'direct' | 'group' | null>(null);
  const [title, setTitle] = useState('');
  const [members, setMembers] = useState<Member[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [draft, setDraft] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [live, setLive] = useState<Live>('connecting');
  const [addable, setAddable] = useState<Person[] | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const onChangedRef = useRef(onChanged);
  onChangedRef.current = onChanged;

  const loadMeta = useCallback(async () => {
    const { data: conv } = await db().from('conversations').select('kind, title').eq('id', conversationId).maybeSingle();
    if (conv) setKind((conv as { kind: 'direct' | 'group' }).kind);

    const { data, error: err } = await db()
      .from('conversation_members')
      .select('user_id, role, profiles(display_name)')
      .eq('conversation_id', conversationId);
    if (err) return setError(errMsg(err));
    type Row = { user_id: string; role: 'owner' | 'member'; profiles: { display_name: string } | { display_name: string }[] | null };
    const list = ((data ?? []) as unknown as Row[]).map((r) => {
      const p = Array.isArray(r.profiles) ? r.profiles[0] : r.profiles;
      return { userId: r.user_id, name: p?.display_name ?? 'Unknown', role: r.role };
    });
    setMembers(list);
    if (conv && (conv as { kind: string }).kind === 'direct') {
      setTitle(list.find((m) => m.userId !== me)?.name ?? 'Conversation');
    } else if (conv) {
      setTitle((conv as { title: string | null }).title ?? 'Group chat');
    }
  }, [conversationId, me]);

  const loadMessages = useCallback(async () => {
    const { data, error: err } = await db()
      .from('messages')
      .select(MESSAGE_COLUMNS)
      .eq('conversation_id', conversationId)
      .order('created_at', { ascending: false })
      .limit(200);
    if (err) return setError(errMsg(err));
    setMessages((prev) => mergeMessages(prev, ((data ?? []) as Message[]).reverse()));
  }, [conversationId]);

  // Load history, then stay subscribed for new messages (and new members) in real time.
  useEffect(() => {
    setLive('connecting');
    void loadMeta();
    void loadMessages();
    const channel = db()
      .channel(`conversation:${conversationId}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'messages', filter: `conversation_id=eq.${conversationId}` },
        (payload) => setMessages((prev) => mergeMessages(prev, [payload.new as Message])),
      )
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'conversation_members', filter: `conversation_id=eq.${conversationId}` },
        () => void loadMeta(),
      )
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          setLive('live');
          void loadMessages(); // fill any gap from while we were disconnected
        } else if (status === 'CLOSED' || status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
          setLive('offline');
        }
      });
    return () => {
      void db().removeChannel(channel);
    };
  }, [conversationId, loadMeta, loadMessages]);

  // Scroll to newest and mark as read.
  const lastId = messages.length ? messages[messages.length - 1]!.id : null;
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ block: 'end' });
    if (!lastId) return;
    void db()
      .rpc('mark_conversation_read', { p_conv: conversationId })
      .then(() => onChangedRef.current());
  }, [lastId, conversationId]);

  async function sendMessage(id: string, body: string) {
    const { data, error: err } = await db()
      .from('messages')
      .insert({ id, conversation_id: conversationId, sender_id: me, body })
      .select(MESSAGE_COLUMNS)
      .single();
    if (err) {
      // 23505 = the first attempt actually landed; just reload instead of showing a failure.
      if ((err as { code?: string }).code === '23505') return void loadMessages();
      setMessages((prev) => markFailed(prev, id));
      return setError(errMsg(err));
    }
    setMessages((prev) => mergeMessages(prev, [data as Message]));
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    const check = validateBody(draft);
    if (!check.ok) return setError(check.error);
    setError(null);
    const id = crypto.randomUUID();
    const optimistic: Message = {
      id,
      conversation_id: conversationId,
      sender_id: me,
      body: check.body,
      created_at: new Date().toISOString(),
      pending: true,
    };
    setMessages((prev) => mergeMessages(prev, [optimistic]));
    setDraft('');
    void sendMessage(id, check.body);
  }

  function retry(m: Message) {
    setError(null);
    setMessages((prev) => markPending(prev, m.id));
    void sendMessage(m.id, m.body);
  }

  function onKeyDown(e: KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      e.currentTarget.form?.requestSubmit();
    }
  }

  const nameOf = (id: string) => members.find((m) => m.userId === id)?.name ?? 'Former member';
  const iAmOwner = members.some((m) => m.userId === me && m.role === 'owner');

  async function openAdd() {
    try {
      const all = await fetchConnections(me);
      const inGroup = new Set(members.map((m) => m.userId));
      setAddable(all.filter((p) => !inGroup.has(p.userId)));
    } catch (e) {
      setError(errMsg(e));
    }
  }

  async function addMember(userId: string) {
    const { error: err } = await db().rpc('add_group_member', { p_conv: conversationId, p_user: userId });
    if (err) return setError(errMsg(err));
    setAddable(null);
    void loadMeta();
  }

  async function leave() {
    if (!window.confirm('Leave this group? You will no longer see its messages.')) return;
    const { error: err } = await db().rpc('leave_group', { p_conv: conversationId });
    if (err) return setError(errMsg(err));
    onLeft();
  }

  return (
    <div className="chat-view">
      <header className="chat-head">
        <button className="back" onClick={onBack} aria-label="Back to chats">←</button>
        <div className="chat-head-main">
          <h2>{title || 'Loading…'}</h2>
          {kind === 'group' && <p className="muted small">{members.map((m) => (m.userId === me ? 'You' : m.name)).join(', ')}</p>}
        </div>
        <span className={`live live-${live}`} role="status" title="Real-time connection">
          {live === 'live' ? 'Live' : live === 'connecting' ? 'Connecting…' : 'Offline — reconnecting'}
        </span>
        {kind === 'group' && (
          <span className="head-actions">
            {iAmOwner && <button onClick={() => void openAdd()}>Add person</button>}
            <button onClick={() => void leave()}>Leave</button>
          </span>
        )}
      </header>

      {addable && (
        <div className="popover" role="dialog" aria-label="Add a person to this group">
          {addable.length === 0 ? (
            <p className="muted">Everyone you are connected with is already here. Invite someone new first.</p>
          ) : (
            <ul>
              {addable.map((p) => (
                <li key={p.userId}>
                  <button onClick={() => void addMember(p.userId)}>Add {p.name}</button>
                </li>
              ))}
            </ul>
          )}
          <button className="link" onClick={() => setAddable(null)}>Close</button>
        </div>
      )}

      <div className="messages" aria-live="polite">
        {messages.length === 0 && <p className="muted center">No messages yet. Say hello!</p>}
        {messages.map((m) => {
          const mine = m.sender_id === me;
          return (
            <div key={m.id} className={mine ? 'bubble-row mine' : 'bubble-row'}>
              <div className={`bubble${m.pending ? ' pending' : ''}${m.failed ? ' failed' : ''}`}>
                {!mine && kind === 'group' && <div className="sender">{nameOf(m.sender_id)}</div>}
                <div className="body">{m.body}</div>
                <div className="meta">
                  {m.failed ? (
                    <button className="link" onClick={() => retry(m)}>Not sent — tap to retry</button>
                  ) : m.pending ? (
                    'Sending…'
                  ) : (
                    timeLabel(m.created_at)
                  )}
                </div>
              </div>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      {error && <p className="error composer-error" role="alert">{error}</p>}
      <form className="composer" onSubmit={onSubmit}>
        <textarea
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={onKeyDown}
          placeholder="Write a message…"
          rows={1}
          maxLength={MAX_MESSAGE_LENGTH}
          aria-label="Message"
        />
        <button className="primary" type="submit" disabled={draft.trim().length === 0}>Send</button>
      </form>
    </div>
  );
}
