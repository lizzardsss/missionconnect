export function Disclaimer() {
  return (
    <footer className="disclaimer">
      MissionConnect is an unofficial concept with fictional demo data. It is not affiliated with, endorsed by, or approved
      by The Church of Jesus Christ of Latter-day Saints.
    </footer>
  );
}
