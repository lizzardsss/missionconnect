import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { useAuth } from '../auth/AuthContext.tsx';
import { db, errMsg } from '../lib/supabase.ts';
import { fetchConnections } from '../lib/api.ts';
import { buildInviteLink, extractInviteCode } from '../lib/invite.ts';
import { AcceptInvite } from './AcceptInvite.tsx';
import type { Invitation, Person } from '../lib/types.ts';

interface Props {
  onOpenChat: (conversationId: string) => void;
  onNewGroup: () => void;
}

const INVITE_COLUMNS = 'id, code, label, status, expires_at, created_at';

export function PeoplePanel({ onOpenChat, onNewGroup }: Props) {
  const { user } = useAuth();
  const me = user!.id;
  const [people, setPeople] = useState<Person[] | null>(null);
  const [invites, setInvites] = useState<Invitation[]>([]);
  const [label, setLabel] = useState('');
  const [codeInput, setCodeInput] = useState('');
  const [acceptCode, setAcceptCode] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      setPeople(await fetchConnections(me));
      const { data, error: err } = await db()
        .from('invitations')
        .select(INVITE_COLUMNS)
        .order('created_at', { ascending: false })
        .limit(50);
      if (err) throw err;
      setInvites((data ?? []) as Invitation[]);
    } catch (e) {
      setError(errMsg(e));
    }
  }, [me]);

  useEffect(() => {
    void load();
  }, [load]);

  async function createInvite(e: FormEvent) {
    e.preventDefault();
    setError(null);
    const { error: err } = await db()
      .from('invitations')
      .insert({ created_by: me, label: label.trim() || null })
      .select(INVITE_COLUMNS)
      .single();
    if (err) return setError(errMsg(err));
    setLabel('');
    void load();
  }

  async function revoke(id: string) {
    const { error: err } = await db().from('invitations').update({ status: 'revoked' }).eq('id', id);
    if (err) return setError(errMsg(err));
    void load();
  }

  async function copy(code: string) {
    const link = buildInviteLink(window.location.origin, code);
    try {
      await navigator.clipboard.writeText(link);
      setCopied(code);
      setTimeout(() => setCopied(null), 2000);
    } catch {
      window.prompt('Copy this private invitation link:', link);
    }
  }

  function startAccept(e: FormEvent) {
    e.preventDefault();
    const code = extractInviteCode(codeInput);
    if (!code) return setError('That does not look like an invitation code or link.');
    setError(null);
    setAcceptCode(code);
  }

  const now = Date.now();
  const pending = invites.filter((i) => i.status === 'pending' && Date.parse(i.expires_at) > now);
  const past = invites.filter((i) => !pending.includes(i));

  return (
    <div className="people stack-lg">
      {error && <p className="error" role="alert">{error}</p>}

      <section className="card stack">
        <h2>Your connections</h2>
        {people === null && <p className="muted" role="status">Loading…</p>}
        {people?.length === 0 && <p className="muted">No one yet. Send a private invitation below.</p>}
        <ul className="plain">
          {people?.map((p) => (
            <li key={p.userId} className="row between">
              <span>{p.name}</span>
              <button onClick={() => onOpenChat(p.conversationId)}>Message</button>
            </li>
          ))}
        </ul>
        {people && people.length > 0 && <button onClick={onNewGroup}>Start a family group chat</button>}
      </section>

      <section className="card stack">
        <h2>Invite someone privately</h2>
        <p className="muted small">
          Each invitation is a single-use link that expires in 7 days. Share it only with the person you mean to connect with.
        </p>
        <form onSubmit={createInvite} className="row">
          <input
            value={label}
            onChange={(e) => setLabel(e.target.value)}
            placeholder="Who is this for? (optional, e.g. Mom)"
            maxLength={40}
            aria-label="Who is this invitation for"
          />
          <button className="primary" type="submit">Create invitation</button>
        </form>
        <ul className="plain">
          {pending.map((i) => (
            <li key={i.id} className="row between wrap">
              <span>
                {i.label ?? 'Invitation'} <span className="muted small">· expires {new Date(i.expires_at).toLocaleDateString()}</span>
              </span>
              <span className="row">
                <button onClick={() => void copy(i.code)}>{copied === i.code ? 'Copied!' : 'Copy link'}</button>
                <button onClick={() => void revoke(i.id)}>Revoke</button>
              </span>
            </li>
          ))}
        </ul>
        {past.length > 0 && (
          <details>
            <summary className="muted small">Past invitations ({past.length})</summary>
            <ul className="plain">
              {past.map((i) => (
                <li key={i.id} className="muted small">
                  {i.label ?? 'Invitation'} — {i.status === 'pending' ? 'expired' : i.status}
                </li>
              ))}
            </ul>
          </details>
        )}
      </section>

      <section className="card stack">
        <h2>Got an invitation?</h2>
        {acceptCode ? (
          <AcceptInvite
            code={acceptCode}
            onCancel={() => setAcceptCode(null)}
            onDone={(conversationId) => {
              setAcceptCode(null);
              setCodeInput('');
              onOpenChat(conversationId);
            }}
          />
        ) : (
          <form onSubmit={startAccept} className="row">
            <input
              value={codeInput}
              onChange={(e) => setCodeInput(e.target.value)}
              placeholder="Paste the invitation link or code"
              aria-label="Invitation link or code"
            />
            <button type="submit">Continue</button>
          </form>
        )}
      </section>
    </div>
  );
}
