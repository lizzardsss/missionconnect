import { useEffect, useState } from 'react';
import { db, errMsg } from '../lib/supabase.ts';

interface Preview {
  inviter_name: string;
  label: string | null;
  valid: boolean;
}

interface Props {
  code: string;
  onDone: (conversationId: string) => void;
  onCancel: () => void;
}

export function AcceptInvite({ code, onDone, onCancel }: Props) {
  const [preview, setPreview] = useState<Preview | null | undefined>(undefined);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      const { data, error: err } = await db().rpc('preview_invitation', { p_code: code });
      if (cancelled) return;
      if (err) {
        setError(errMsg(err));
        setPreview(null);
        return;
      }
      const row = ((data ?? []) as Preview[])[0];
      setPreview(row ?? null);
    })();
    return () => {
      cancelled = true;
    };
  }, [code]);

  async function accept() {
    setBusy(true);
    setError(null);
    const { data, error: err } = await db().rpc('accept_invitation', { p_code: code });
    setBusy(false);
    if (err) return setError(errMsg(err));
    onDone(data as string);
  }

  if (preview === undefined) return <p role="status">Checking invitation…</p>;

  if (preview === null || !preview.valid) {
    return (
      <div className="stack">
        <h2>Invitation unavailable</h2>
        <p>
          This invitation is not valid. It may have expired, been revoked, already been used, or be one you created
          yourself. Ask the sender for a new one.
        </p>
        {error && <p className="error" role="alert">{error}</p>}
        <button className="primary" onClick={onCancel}>Continue</button>
      </div>
    );
  }

  return (
    <div className="stack">
      <h2>Connect with {preview.inviter_name}?</h2>
      <p>
        <strong>{preview.inviter_name}</strong> sent you a private invitation. If you accept, the two of you can message
        each other. Only people you invite or accept can reach you.
      </p>
      {error && <p className="error" role="alert">{error}</p>}
      <div className="row">
        <button className="primary" onClick={accept} disabled={busy}>{busy ? 'Connecting…' : 'Accept'}</button>
        <button onClick={onCancel} disabled={busy}>Not now</button>
      </div>
    </div>
  );
}
