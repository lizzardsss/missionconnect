import { useEffect, useState, type FormEvent } from 'react';
import { useAuth } from '../auth/AuthContext.tsx';
import { db, errMsg } from '../lib/supabase.ts';
import { fetchConnections } from '../lib/api.ts';
import type { Person } from '../lib/types.ts';

interface Props {
  onClose: () => void;
  onCreated: (conversationId: string) => void;
}

export function NewGroupModal({ onClose, onCreated }: Props) {
  const { user } = useAuth();
  const [people, setPeople] = useState<Person[] | null>(null);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [title, setTitle] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    fetchConnections(user.id).then(setPeople, (e) => setError(errMsg(e)));
  }, [user]);

  function toggle(id: string) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    if (title.trim().length === 0) return setError('Give the group a name, like “The Smith Family”.');
    if (selected.size === 0) return setError('Choose at least one person.');
    setBusy(true);
    const { data, error: err } = await db().rpc('create_group_chat', {
      p_title: title.trim(),
      p_member_ids: [...selected],
    });
    setBusy(false);
    if (err) return setError(errMsg(err));
    onCreated(data as string);
  }

  return (
    <div className="modal-backdrop" role="presentation" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <form className="modal stack" onSubmit={submit} role="dialog" aria-modal="true" aria-label="New family group chat">
        <h2>New family group chat</h2>
        <label>
          Group name
          <input value={title} onChange={(e) => setTitle(e.target.value)} maxLength={60} placeholder="The Smith Family" autoFocus />
        </label>
        <fieldset>
          <legend>Add people you are connected with</legend>
          {people === null && <p className="muted" role="status">Loading…</p>}
          {people?.length === 0 && <p className="muted">You have no connections yet. Send an invitation first.</p>}
          {people?.map((p) => (
            <label key={p.userId} className="check">
              <input type="checkbox" checked={selected.has(p.userId)} onChange={() => toggle(p.userId)} />
              {p.name}
            </label>
          ))}
        </fieldset>
        {error && <p className="error" role="alert">{error}</p>}
        <div className="row">
          <button className="primary" type="submit" disabled={busy}>{busy ? 'Creating…' : 'Create group'}</button>
          <button type="button" onClick={onClose} disabled={busy}>Cancel</button>
        </div>
      </form>
    </div>
  );
}
